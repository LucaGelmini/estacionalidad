# Estacionalidad!

Próximamente añado una descripcion acorde.
Coming soon: a reasonable description.
